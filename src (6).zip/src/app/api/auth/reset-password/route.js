import { NextResponse } from "next/server";
import { apiErrorResponse } from "@/lib/apiErrorResponse";

const BACKEND_URL =
  process.env.BACKEND_API_URL ||
  "http://localhost:8081/api";

async function readResponse(response) {
  const text = await response.text();

  if (!text) {
    return {};
  }

  try {
    return JSON.parse(text);
  } catch {
    return {
      message: text,
    };
  }
}

export async function POST(request) {
  try {
    const body = await request.json();

    const phoneOrEmail = String(
      body.phoneOrEmail ||
        body.phone ||
        body.email ||
        "",
    ).trim();

    const otp = String(
      body.otp ||
        body.code ||
        "",
    ).trim();

    const newPassword = String(
      body.newPassword ||
        body.password ||
        "",
    );

    if (!phoneOrEmail) {
      return NextResponse.json(
        {
          success: false,
          message: "រកមិនឃើញលេខទូរស័ព្ទ ឬអ៊ីមែល",
        },
        {
          status: 400,
        },
      );
    }

    if (!/^\d{6}$/.test(otp)) {
      return NextResponse.json(
        {
          success: false,
          message: "លេខកូដ OTP មិនត្រឹមត្រូវ",
        },
        {
          status: 400,
        },
      );
    }

    if (!newPassword) {
      return NextResponse.json(
        {
          success: false,
          message: "សូមបញ្ចូលលេខសម្ងាត់ថ្មី",
        },
        {
          status: 400,
        },
      );
    }

    if (newPassword.length < 6) {
      return NextResponse.json(
        {
          success: false,
          message: "ពាក្យសម្ងាត់ត្រូវមានយ៉ាងហោចណាស់ ៦ តួអក្សរ",
        },
        {
          status: 400,
        },
      );
    }

    const backendResponse = await fetch(
      `${BACKEND_URL}/auth/reset-password`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          phoneOrEmail,
          otp,
          newPassword,
        }),
        cache: "no-store",
      },
    );

    const data = await readResponse(
      backendResponse,
    );

    if (!backendResponse.ok) {
      return NextResponse.json(
        {
          success: false,
          message:
            data?.message ||
            data?.error ||
            data?.detail ||
            "មិនអាចប្ដូរលេខសម្ងាត់បាន",
        },
        {
          status: backendResponse.status,
        },
      );
    }

    return NextResponse.json(
      {
        success: true,
        message:
          data?.message ||
          "លេខសម្ងាត់ត្រូវបានប្ដូរដោយជោគជ័យ",
      },
      {
        status: 200,
      },
    );
  } catch (error) {
    console.error(
      "Reset password route error:",
      error,
    );

    return apiErrorResponse(
      "BACKEND_UNAVAILABLE",
      "មានបញ្ហាក្នុងការប្ដូរលេខសម្ងាត់",
      502,
    );
  }
}
