"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ChevronRight } from "lucide-react";
import { HiSaveAs } from "react-icons/hi";
import { RiDownloadCloud2Line } from "react-icons/ri";

import Pagination from "@/components/navigation/Pagination";
import { ReceiptIcon } from "@/components/donations/monthlydonation/AddDonationTableRow";
import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { normalizeRole } from "@/lib/navigation";
import { downloadTableAsExcel } from "@/utils/downloadExcel";
const ROWS_PER_PAGE = 10;
const KHR_PER_USD = 4000;

function createInitialRows(members = []) {
  const getMemberIdentity = (member) =>
    String(
      member.email ||
        member.phone ||
        member.full_name_km ||
        member.name_kh ||
        member.name_en ||
        member.name ||
        member.id
    )
      .trim()
      .toLowerCase();

  const uniqueMembers = Array.from(
    new Map(
      members.map((member) => [
        getMemberIdentity(member),
        member,
      ])
    ).values()
  );

  return uniqueMembers.map((member) => ({
    id: member.id,
    name:
      member.name_kh ||
      member.fullNameKm ||
      member.name ||
      member.full_name_en ||
      member.name_en ||
      member.fullNameEn ||
      "",
    gender: member.gender?.label_km || member.gender?.labelKm || member.gender?.code || member.gender || "",
    joinedDate:
      member.joined_on ||
      member.joinedDate ||
      member.joinedAt ||
      "",

    amountRiel: "0",
    amountDollar: "0.00",

    paymentMethod: "Cash",
    receipt: null,
  }));
}

async function fetchJson(path, options = {}) {
  const response = await fetch(path, { cache: "no-store", ...options });
  const body = await response.json().catch(() => null);
  if (!response.ok) throw new Error(body?.message || `Request failed (${response.status})`);
  return body;
}

function parseAmount(value) {
  const number = Number(value);

  return Number.isFinite(number)
    ? number
    : 0;
}

function sanitizeInteger(value) {
  return value.replace(/\D/g, "");
}

function sanitizeDecimal(value) {
  let cleanedValue = value.replace(
    /[^\d.]/g,
    ""
  );

  const parts = cleanedValue.split(".");

  if (parts.length > 2) {
    cleanedValue =
      parts[0] +
      "." +
      parts.slice(1).join("");
  }

  if (cleanedValue.includes(".")) {
    const [whole, decimal = ""] =
      cleanedValue.split(".");

    cleanedValue = `${whole}.${decimal.slice(
      0,
      2
    )}`;
  }

  return cleanedValue;
}

const getAmountFieldClass = (value) =>
  Number(value) > 0
    ? "border-border bg-success-bg"
    : "border-border bg-bg-page-gray";

function getTotalInDollars(row) {
  return (
    parseAmount(row.amountDollar) +
    parseAmount(row.amountRiel) / KHR_PER_USD
  );
}

function mergeSavedIncome(rows, savedItems = []) {
  const savedByMember = new Map();

  savedItems.forEach((item) => {
    const key = String(item.memberId);
    const current = savedByMember.get(key) || {
      amountKhr: 0,
      amountUsd: 0,
      paymentMethodCode: "",
    };

    current.amountKhr += Number(item.amountKhr || 0);
    current.amountUsd += Number(item.amountUsd || 0);
    current.paymentMethodCode =
      current.paymentMethodCode || item.paymentMethodCode || "";
    savedByMember.set(key, current);
  });

  return rows.map((row) => {
    const saved = savedByMember.get(String(row.id));
    if (!saved) return row;

    return {
      ...row,
      amountRiel: String(saved.amountKhr),
      amountDollar: saved.amountUsd.toFixed(2),
      paymentMethod: saved.paymentMethodCode || row.paymentMethod,
    };
  });
}

export default function IncomePage() {
  const { user } = useAuth();
  const { t, label } = useLanguage();
  const isReadOnly = normalizeRole(user?.role) === "viewer";
  const router = useRouter();
  const searchParams = useSearchParams();
  const activityId =
    searchParams.get("activityId");

  const [activity, setActivity] = useState(null);
  const [rows, setRows] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");

  const [currentPage, setCurrentPage] =
    useState(1);

  useEffect(() => {
    if (!activityId) return;
    let cancelled = false;

    async function loadIncomeData() {
      try {
        setError("");
        const activityRecord = await fetchJson(`/api/backend/activities/${encodeURIComponent(activityId)}`);
        const [memberPage, methods, incomeDetailResponse] = await Promise.all([
          fetchJson(`/api/backend/members?branchId=${activityRecord.branchId}&page=0&size=100`),
          fetchJson("/api/lookups/payment-methods?activeOnly=true&includeMaterial=true"),
          fetchJson(`/api/backend/activities/${encodeURIComponent(activityId)}/incomes`),
        ]);
        const members = Array.isArray(memberPage) ? memberPage : memberPage?.content || [];
        const methodList = Array.isArray(methods) ? methods : [];
        const defaultMethod = methodList[0]?.code || "Cash";
        const incomeDetail = incomeDetailResponse?.data ?? incomeDetailResponse;
        const savedItems = Array.isArray(incomeDetail?.items) ? incomeDetail.items : [];
        const initialRows = createInitialRows(members).map((row) => ({
          ...row,
          paymentMethod: defaultMethod,
        }));
        if (!cancelled) {
          setActivity({ ...activityRecord, name: activityRecord.titleKm || activityRecord.titleEn || "" });
          setRows(mergeSavedIncome(initialRows, savedItems));
          setPaymentMethods(methodList);
        }
      } catch (loadError) {
        if (!cancelled) setError(loadError.message || t("donationPage.loadIncomeFailed"));
      }
    }

    loadIncomeData();
    return () => {
      cancelled = true;
    };
  }, [activityId]);

  const totalPages = Math.max(
    1,
    Math.ceil(
      rows.length / ROWS_PER_PAGE
    )
  );

  const pagedRows = useMemo(() => {
    const startIndex =
      (currentPage - 1) *
      ROWS_PER_PAGE;

    return rows.slice(
      startIndex,
      startIndex + ROWS_PER_PAGE
    );
  }, [rows, currentPage]);

  const updateRow = (
    rowId,
    field,
    value
  ) => {
    setRows((currentRows) =>
      currentRows.map((row) =>
        row.id === rowId
          ? {
              ...row,
              [field]: value,
            }
          : row
      )
    );
  };

  const handleAmountFocus = (rowId, field, value) => {
    if (parseAmount(value) === 0) {
      updateRow(rowId, field, "");
    }
  };

  const handleAmountBlur = (rowId, field, fallback) => {
    setRows((currentRows) =>
      currentRows.map((row) =>
        row.id === rowId && row[field] === ""
          ? { ...row, [field]: fallback }
          : row
      )
    );
  };

  const handleReceiptChange = (
    rowId,
    event
  ) => {
    const file =
      event.target.files?.[0] || null;

    updateRow(rowId, "receipt", file);
  };

  const summary = useMemo(() => {
    return rows.reduce(
      (total, row) => ({
        riel:
          total.riel +
          parseAmount(row.amountRiel),

        dollar:
          total.dollar +
          parseAmount(
            row.amountDollar
          ),

        totalDollar:
          total.totalDollar +
          getTotalInDollars(row),
      }),
      {
        riel: 0,
        dollar: 0,
        totalDollar: 0,
      }
    );
  }, [rows]);

  const handleDownloadReport = () => {
    const exportColumns = [
      { header: t("donationPage.no"), accessor: "no" },
      { header: t("donationPage.member"), accessor: "name" },
      { header: t("donationPage.gender"), accessor: "gender" },
      { header: t("donationPage.joinedDate"), accessor: "joinedDate" },
      { header: t("donationPage.amountKhr"), accessor: "amountRiel" },
      { header: t("donationPage.amountUsd"), accessor: "amountDollar" },
      { header: t("donationPage.paymentMethod"), accessor: "paymentMethodLabel" },
    ];
    const activeRows = rows
      .filter((row) => parseAmount(row.amountRiel) > 0 || parseAmount(row.amountDollar) > 0)
      .map((row, index) => {
        const method = paymentMethods.find((item) => item.code === row.paymentMethod);

        return {
          ...row,
          no: index + 1,
          paymentMethodLabel:
            label(method, row.paymentMethod),
        };
      });

    downloadTableAsExcel({
      data: activeRows,
      columns: exportColumns,
      fileName: `income-${activity?.name || activityId || "report"}`,
    });
  };

  const handleSave = async () => {
    const activeRows = rows.filter(
      (row) => parseAmount(row.amountRiel) > 0 || parseAmount(row.amountDollar) > 0,
    );
    if (!activityId || activeRows.length === 0) {
      setError(t("donationPage.incomeAmountRequired"));
      return;
    }

    setIsSaving(true);
    setError("");
    try {
      const items = await Promise.all(
        activeRows.map(async (row) => {
          let receiptFileId = null;
          if (row.receipt) {
            const data = new FormData();
            data.append("file", row.receipt);
            const uploaded = await fetchJson("/api/backend/files/attachments", {
              method: "POST",
              body: data,
            });
            receiptFileId = uploaded.id;
          }
          const method = paymentMethods.find((item) => item.code === row.paymentMethod);
          return {
            member_id: Number(row.id),
            amount_khr: parseAmount(row.amountRiel),
            amount_usd: parseAmount(row.amountDollar),
            payment_method_id: Number(method?.id),
            receipt_file_id: receiptFileId,
          };
        }),
      );
      if (items.some((item) => !Number.isFinite(item.payment_method_id))) {
        throw new Error(t("donationPage.paymentMethodRequired"));
      }
      await fetchJson(`/api/backend/activities/${encodeURIComponent(activityId)}/incomes/batch`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ received_at: new Date().toISOString(), items }),
      });
      router.push(`/activity/${activityId}`);
    } catch (saveError) {
      setError(saveError.message || t("donationPage.saveIncomeFailed"));
    } finally {
      setIsSaving(false);
    }
  };

  const cancelHref = activityId
    ? `/activity/${activityId}`
    : "/activity/create";

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-center gap-1 text-sm text-text-secondary">
          <Link
            href="/activity"
            className="hover:text-primary"
          >
            {t("donationPage.activity")}
          </Link>

          <ChevronRight size={14} />

          {activityId && (
            <>
              <Link
                href={`/activity/${activityId}`}
                className="hover:text-primary"
              >
                {t("donationPage.detailInfo")}
              </Link>

              <ChevronRight size={14} />
            </>
          )}

          <span className="font-semibold text-primary">
            {t("donationPage.income")}
          </span>
        </div>

        <h1 className="mt-3 text-2xl font-bold text-secondary">
          {t("donationPage.income")}
        </h1>

        {activity?.name && (
          <p className="mt-1 text-sm text-text-secondary">
            {activity.name}
          </p>
        )}
      </div>

      {error && (
        <div className="rounded-lg border border-error/30 bg-error-bg px-4 py-3 text-sm text-error">
          {error}
        </div>
      )}

      {/* Income table */}
      <div className="rounded-xl border border-border bg-bg-page-white p-5">
        <div className="mb-4 flex justify-end">
          <button
            type="button"
            onClick={handleDownloadReport}
            className="flex h-[34px] items-center gap-2 rounded-lg bg-secondary px-5 text-sm font-semibold text-white transition hover:bg-secondary-hover"
          >
            <RiDownloadCloud2Line
              size={18}
            />

            {t("donationPage.downloadReport")}
          </button>
        </div>

        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full min-w-[1050px] table-fixed border-collapse text-[12px] text-text-secondary">
            <thead>
              <tr className="h-11 border-b border-border bg-bg-page-gray font-medium text-text-secondary">
                <th className="w-[5%] text-center">
                  {t("donationPage.no")}
                </th>

                <th className="w-[15%] text-center">
                  {t("donationPage.member")}
                </th>

                <th className="w-[8%] text-center">
                  {t("donationPage.gender")}
                </th>

                <th className="w-[12%] text-center">
                  {t("donationPage.joinedDate")}
                </th>

                <th className="w-[17%] text-center">
                  {t("donationPage.amountKhr")}
                </th>

                <th className="w-[17%] text-center">
                  {t("donationPage.amountUsd")}
                </th>

                <th className="w-[18%] text-center">
                  {t("donationPage.paymentMethod")}
                </th>

                <th className="w-[8%] text-center">
                  {t("donationPage.receipt")}
                </th>
              </tr>
            </thead>

            <tbody>
              {pagedRows.map(
                (row, index) => {
                  const realIndex =
                    (currentPage - 1) *
                      ROWS_PER_PAGE +
                    index;

                  return (
                    <tr
                      key={row.id}
                      className="h-[42px] border-b border-border bg-bg-page-white text-[12px] text-text-secondary transition-colors hover:bg-bg-page-gray"
                    >
                      <td className="text-center text-text-secondary">
                        {realIndex + 1}
                      </td>

                      <td className="max-w-0 overflow-hidden px-2">
                        <p className="truncate font-medium text-text-primary" title={row.name}>
                          {row.name}
                        </p>
                      </td>

                      <td className="text-center text-text-secondary">
                        {row.gender}
                      </td>

                      <td className="text-center text-text-secondary">
                        {row.joinedDate}
                      </td>

                      {/* Independent riel input */}
                      <td className="px-3">
                        <div className={`mx-auto flex h-7 w-[112px] items-center gap-1 rounded-md border px-2 ${getAmountFieldClass(row.amountRiel)}`}>
                          <input
                            type="text"
                            inputMode="numeric"
                            value={
                              row.amountRiel
                            }
                            readOnly={isReadOnly}
                            onChange={(
                              event
                            ) => {
                              const value =
                                sanitizeInteger(
                                  event
                                    .target
                                    .value
                                );

                              updateRow(
                                row.id,
                                "amountRiel",
                                value
                              );
                            }}
                            onFocus={() =>
                              handleAmountFocus(
                                row.id,
                                "amountRiel",
                                row.amountRiel
                              )
                            }
                            onBlur={() =>
                              handleAmountBlur(
                                row.id,
                                "amountRiel",
                                "0"
                              )
                            }
                            placeholder={row.amountRiel ? "" : "0"}
                            className="w-full bg-transparent text-[12px] text-text-secondary outline-none placeholder:text-text-secondary"
                          />

                          <span className="text-[12px] text-text-secondary">
                            ៛
                          </span>
                        </div>
                      </td>

                      {/* Independent dollar input */}
                      <td className="px-3">
                        <div className={`mx-auto flex h-7 w-[112px] items-center gap-1 rounded-md border px-2 ${getAmountFieldClass(row.amountDollar)}`}>
                          <input
                            type="text"
                            inputMode="decimal"
                            value={
                              row.amountDollar
                            }
                            readOnly={isReadOnly}
                            onChange={(
                              event
                            ) => {
                              const value =
                                sanitizeDecimal(
                                  event
                                    .target
                                    .value
                                );

                              updateRow(
                                row.id,
                                "amountDollar",
                                value
                              );
                            }}
                            onFocus={() =>
                              handleAmountFocus(
                                row.id,
                                "amountDollar",
                                row.amountDollar
                              )
                            }
                            onBlur={() =>
                              handleAmountBlur(
                                row.id,
                                "amountDollar",
                                "0.00"
                              )
                            }
                            placeholder={row.amountDollar ? "" : "0.00"}
                            className="w-full bg-transparent text-[12px] text-text-secondary outline-none placeholder:text-text-secondary"
                          />

                          <span className="text-[12px] text-text-secondary">
                            $
                          </span>
                        </div>
                      </td>

                      <td className="px-3">
                        <select
                          disabled={isReadOnly}
                          value={
                            row.paymentMethod
                          }
                          onChange={(
                            event
                          ) =>
                            updateRow(
                              row.id,
                              "paymentMethod",
                              event
                                .target
                                .value
                            )
                          }
                          className="mx-auto block h-7 w-[82px] rounded-md border border-border bg-bg-page-white px-2 text-[12px] text-text-secondary outline-none focus:border-secondary"
                        >
                          {paymentMethods.map((method) => (
                            <option key={method.id} value={method.code}>
                              {label(method, method.code)}
                            </option>
                          ))}
                          
                        </select>
                      </td>

                      <td className="px-3 text-center">
                        <label
                          className={`inline-flex h-7 w-7 items-center justify-center rounded-md text-secondary ${isReadOnly ? "cursor-default opacity-50" : "cursor-pointer hover:bg-secondary-light/10"}`}
                          aria-label="receipt"
                        >
                          <ReceiptIcon size={18} />

                          <input
                            type="file"
                            disabled={isReadOnly}
                            accept="image/*,.pdf"
                            className="hidden"
                            onChange={(
                              event
                            ) =>
                              handleReceiptChange(
                                row.id,
                                event
                              )
                            }
                          />

                        </label>
                      </td>
                    </tr>
                  );
                }
              )}

              {pagedRows.length === 0 && (
                <tr>
                  <td
                    colSpan={8}
                    className="py-10 text-center text-sm text-text-secondary"
                  >
                    {t("donationPage.noMemberData")}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="mt-4">
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={
              setCurrentPage
            }
          />
        </div>

        {/* Summary */}
        <div
          className="ml-auto mt-5 w-full max-w-[360px] rounded-lg border border-border p-4"
          aria-live="polite"
        >
          <h3 className="mb-3 font-bold text-secondary">
            {t("donationPage.totalIncome")}
          </h3>

          <div className="flex justify-between gap-5 text-sm text-text-secondary">
            <span>
              {t("donationPage.totalIncomeKhr")}
            </span>

            <span className="font-semibold text-text-primary">
              {summary.riel.toLocaleString()}
              {" "}៛
            </span>
          </div>

          <div className="mt-2 flex justify-between gap-5 text-sm text-text-secondary">
            <span>
              {t("donationPage.totalIncomeUsd")}
            </span>

            <span className="font-semibold text-text-primary">
              {summary.dollar.toFixed(2)}
              {" "}$
            </span>
          </div>

          <div className="mt-3 flex justify-between gap-5 border-t border-border pt-3 font-bold text-secondary">
            <span>
              {t("donationPage.totalAllUsd")}
            </span>

            <span>
              {summary.totalDollar.toFixed(2)}
              {" "}$
            </span>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col gap-3 sm:flex-row sm:justify-between">
        <Link
          href={cancelHref}
          className="flex h-[34px] w-full items-center justify-center rounded-lg border border-border bg-bg-page-white text-sm font-semibold text-text-secondary transition hover:bg-bg-page-gray sm:w-[91px]"
        >
          {t("donationPage.cancel")}
        </Link>

        {!isReadOnly && (
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="flex h-[34px] w-full items-center justify-center gap-2 rounded-lg bg-secondary text-sm font-semibold text-white transition hover:bg-secondary-hover sm:w-[196px]"
          >
            <HiSaveAs size={16} />

            {t("donationPage.save")}
          </button>
        )}
      </div>
    </div>
  );
}
