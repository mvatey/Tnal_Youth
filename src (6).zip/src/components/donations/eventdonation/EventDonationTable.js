"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowDown, ArrowUp, ChevronsUpDown, List } from "lucide-react";
import Pagination from "@/components/navigation/Pagination";
import SaveButton from "@/components/forms/save";
import { useLanguage } from "@/context/LanguageContext";

export default function EventDonationTable({
  rows,
  currentPage,
  totalPages,
  onPageChange,
  onDownload,
  moneySort,
  onMoneySort,
}) {
  const pathname = usePathname();
  const { t } = useLanguage();
  const detailPath = pathname?.startsWith("/admin/donation")
    ? "/admin/donation/eventdonation/detail"
    : "/donation/eventdonation/detail";

  const headers = [
    t("donationPage.no"),
    t("donationPage.activity"),
    t("donationPage.branch"),
    t("donationPage.startDate"),
    t("donationPage.endDate"),
    t("donationPage.days"),
    t("donationPage.amountKhrPlain"),
    t("donationPage.amountUsdPlain"),
    t("common.actions", "សកម្មភាព"),
  ];

  return (
    <>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[980px] border-collapse border border-border">
          <thead>
            <tr className="h-12 border-b border-border bg-bg-page-gray text-center text-xs font-medium text-text-secondary">
              {headers.map((header, index) => (
                <th key={header} className="px-4">
                  {index === 6 || index === 7 ? (
                    <button
                      type="button"
                      onClick={() => onMoneySort(index === 6 ? "rielAmount" : "dollarAmount")}
                      className="mx-auto inline-flex items-center justify-center gap-1.5 font-medium transition hover:text-primary"
                    >
                      {header}
                      {moneySort?.field === (index === 6 ? "rielAmount" : "dollarAmount") && moneySort.direction === "asc" ? (
                        <ArrowUp size={14} />
                      ) : moneySort?.field === (index === 6 ? "rielAmount" : "dollarAmount") && moneySort.direction === "desc" ? (
                        <ArrowDown size={14} />
                      ) : (
                        <ChevronsUpDown size={14} />
                      )}
                    </button>
                  ) : header}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {rows.map((row) => (
              <tr
                key={row.id}
                className="h-11 border-b border-border text-center text-sm text-text-secondary last:border-b-0"
              >
                <td className="px-4 font-normal">{row.rowNumber}</td>
                <td className="px-4">{row.eventName}</td>
                <td className="px-4">{row.branch}</td>
                <td className="whitespace-nowrap px-4">{row.startDate}</td>
                <td className="whitespace-nowrap px-4">{row.endDate}</td>
                <td className="px-4">{row.days}</td>
                <td className="px-4">{row.rielAmount}</td>
                <td className="px-4">{row.dollarAmount}</td>
                <td className="px-4">
                  <div className="flex items-center justify-center gap-[5px]">
                    <Link
                      href={{
                        pathname: detailPath,
                        query: {
                          id: row.id,
                          branch: row.branchId,
                          event: row.activityId,
                        },
                      }}
                      className="inline-flex h-[18px] min-w-[52px] items-center justify-center gap-[3px] rounded-[8px] bg-[#5636A3] px-2 text-[10px] font-normal leading-none text-white transition hover:bg-[#4b2f91]"
                    >
                      <List size={11} strokeWidth={2.2} />
                      {t("donationPage.detail")}
                    </Link>
                  </div>
                </td>
              </tr>
            ))}

            {rows.length === 0 && (
              <tr>
                <td
                  colSpan={headers.length}
                  className="px-4 py-8 text-center text-xs font-medium text-text-secondary"
                >
                  {t("donationPage.noData")}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={onPageChange}
      />

      <div className="mt-10 flex justify-end">
        <SaveButton onClick={onDownload} disabled={!rows || rows.length === 0} />
      </div>
    </>
  );
}
