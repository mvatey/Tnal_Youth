import { Search, Plus, ChevronDown } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export default function DocumentFilters({
  activeTab,
  query,
  setQuery,
  branchFilter,
  setBranchFilter,
  dateFilter,
  setDateFilter,
  resetPage,
  onAdd,
}) {
  const { t } = useLanguage();
  const isMember = activeTab === "member";

  return (
    <div className="shrink-0 border-b border-border p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:gap-4">
        <div className="relative w-full lg:w-[260px]">
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              resetPage();
            }}
            placeholder={t("documentPage.searchPlaceholder")}
            className="h-[38px] w-full rounded-md border border-border px-4 pr-10 text-sm outline-none focus:border-[#5b2cc9]"
          />
          <Search className="absolute right-3 top-2.5 h-4 w-4 text-text-mute" />
        </div>

        <div className="relative w-full sm:w-[180px]">
          <select
            value={branchFilter}
            onChange={(e) => {
              setBranchFilter(e.target.value);
              resetPage();
            }}
            className="h-[38px] w-full appearance-none rounded-md border border-border px-4 pr-10 text-sm outline-none focus:border-[#5b2cc9]"
          >
            <option value="">{t("documentPage.branch")}</option>
            <option value="សាខាភ្នំពេញ">សាខាភ្នំពេញ</option>
            <option value="សាខាសៀមរាប">សាខាសៀមរាប</option>
          </select>

          <ChevronDown className="pointer-events-none absolute right-3 top-3 h-4 w-4 text-text-mute" />
        </div>

        <div className="w-full sm:w-[240px]">
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => {
              setDateFilter(e.target.value);
              resetPage();
            }}
            className="h-[38px] w-full rounded-md border border-border px-4 text-sm outline-none focus:border-[#5b2cc9]"
          />
        </div>

        <button
          onClick={onAdd}
          className="flex h-[38px] w-full items-center justify-center gap-2 rounded-md bg-[#118447] px-4 text-sm font-medium text-white hover:bg-[#0d6f3b] sm:w-auto lg:ml-auto"
        >
          <Plus className="h-5 w-5" />
          {isMember ? t("documentPage.createDocument") : t("documentPage.addDocument")}
        </button>
      </div>
    </div>
  );
}
