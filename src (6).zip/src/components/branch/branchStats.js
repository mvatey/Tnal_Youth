"use client";

import {
  Building2,
  BadgeCheck,
  Users,
} from "lucide-react";

import { useLanguage } from "@/context/LanguageContext";

const STAT_CONFIG = [
  {
    key: "totalBranches",
    label: "ចំនួនសាខាសរុប",
    labelKey: "branchPage.totalBranches",
    Icon: Building2,
    iconClass:
      "bg-secondary-light text-secondary",
    borderClass: "border-t-secondary",
  },
  {
    key: "subBranches",
    label: "ចំនួនអនុសាខា",
    labelKey: "branchPage.subBranches",
    Icon: BadgeCheck,
    iconClass: "bg-warning-bg text-warning",
    borderClass: "border-t-warning",
  },
  {
    key: "totalMembers",
    label: "ចំនួនសមាជិកសរុប",
    labelKey: "branchPage.totalMembers",
    Icon: Users,
    iconClass:
      "bg-success-bg text-success",
    borderClass: "border-t-success",
  },
];

export default function BranchStats({ branches = [] }) {
  const { t } =
    useLanguage();

  const isProvincialLevel = (branch) => {
    const level = String(
      branch.levelCode ||
      branch.level ||
      "",
    )
      .trim()
      .toUpperCase();

    return (
      level === "PROVINCE" ||
      level === "រាជធានី/ខេត្ត"
    );
  };

  const values = {
    totalBranches: branches.length,

    subBranches: branches.filter(
      (branch) => !isProvincialLevel(branch),
    ).length,

    totalMembers: branches.reduce(
      (total, branch) =>
        total + Number(branch.memberCount || 0),
      0,
    ),
  };


  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
      {STAT_CONFIG.map(
        ({
          key,
          label,
          labelKey,
          Icon,
          iconClass,
          borderClass,
        }) => (
          <div
            key={key}
            className={`rounded-xl border border-border border-t-3 bg-bg-page-white p-5 shadow-sm ${borderClass}`}
          >
            <div className="flex items-center gap-4">
              <div
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${iconClass}`}
              >
                <Icon size={19} />
              </div>

              <div>
                <p className="text-xs text-text-secondary">
                  {t(labelKey, label)}
                </p>

                <p className="mt-1 text-2xl font-bold text-text-primary">
                  {values[key]}
                </p>
              </div>
            </div>
          </div>
        ),
      )}
    </div>
  );
}
