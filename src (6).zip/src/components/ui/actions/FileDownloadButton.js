"use client";

import { TbFileTypePdf } from "react-icons/tb";

export default function FileDownloadButton({
  fileName = "បញ្ជីកម្មវិធី.pdf",
  fileSize = "2.9 MB",
  onClick,
  className = "",
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex min-h-[72px] w-full max-w-[304px] items-center gap-3 rounded-2xl bg-bg-page-white px-4 py-3 text-left shadow-[0_2px_5px_rgba(0,0,0,0.22)] transition hover:bg-bg-page-gray focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-secondary ${className}`}
      aria-label={`${fileName}, ${fileSize}`}
    >
      <TbFileTypePdf
        aria-hidden="true"
        className="shrink-0 text-[#e5252a]"
        size={44}
        strokeWidth={1.8}
      />

      <span className="min-w-0">
        <span className="block truncate text-[20px] font-semibold leading-7 text-text-primary">
          {fileName}
        </span>
        <span className="block text-[14px] font-normal leading-5 text-text-primary">
          {fileSize}
        </span>
      </span>
    </button>
  );
}
