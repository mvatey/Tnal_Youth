// components/dashboard/quickActions.jsx
"use client";

import Link from "next/link";
import { CirclePlus, Eye } from "lucide-react";

import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { normalizeRole } from "@/lib/navigation";

const CREATE_ACTIONS = [
  {
    id: "program",
    label: "បង្កើតកម្មវិធី",
    labelKey: "dashboard.createActivity",
    href: "/activity/create",
    icon: CirclePlus,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
  {
    id: "branch",
    label: "បង្កើតឯកសារ",
    labelKey: "dashboard.createDocument",
    href: "/document/create",
    icon: CirclePlus,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
  {
    id: "activity",
    label: "បង្កើតវិភាគទាន",
    labelKey: "dashboard.createDonation",
    href: "/donation/add",
    icon: CirclePlus,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
  {
    id: "member",
    label: "បង្កើតសមាជិក",
    labelKey: "dashboard.createMember",
    href: "/member",
    icon: CirclePlus,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
];

// Read-only equivalent of DEFAULT_ACTIONS, shown to VIEWER accounts instead
// of the create-action set — same four destinations, but every action is a
// plain "view" link (Eye icon) rather than something implying a write the
// backend's ViewerWriteBlockFilter would reject anyway.
const VIEWER_ACTIONS = [
  {
    id: "view-program",
    label: "មើលកម្មវិធី",
    labelKey: "dashboard.viewActivity",
    href: "/activity",
    icon: Eye,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
  {
    id: "view-branch",
    label: "មើលឯកសារ",
    labelKey: "dashboard.viewDocument",
    href: "/document",
    icon: Eye,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
  {
    id: "view-activity",
    label: "មើលវិភាគទាន",
    labelKey: "dashboard.viewDonation",
    href: "/donation",
    icon: Eye,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
  {
    id: "view-member",
    label: "មើលសមាជិក",
    labelKey: "dashboard.viewMember",
    href: "/member",
    icon: Eye,
    color: "text-primary",
    bg: "bg-bg-page-gray",
  },
];

const ADMIN_ACTIONS = [
  ...VIEWER_ACTIONS.filter((action) => action.id !== "view-member"),
  CREATE_ACTIONS.find((action) => action.id === "member"),
].filter(Boolean);

export default function QuickActions() {
  const { user, authLoading } = useAuth();
  const { t } =
    useLanguage();

  const role = normalizeRole(user?.role);

  const actions =
    role === "viewer"
      ? VIEWER_ACTIONS
      : role === "admin"
        ? ADMIN_ACTIONS
        : CREATE_ACTIONS;

  if (authLoading) {
    return (
      <div className="app-card flex h-full items-center justify-center rounded-xl border border-border bg-bg-page-white p-4">
        <p className="text-sm text-text-secondary">
          {t("dashboard.loadingShort")}
        </p>
      </div>
    );
  }

  return (
    <div className="app-card flex h-full min-w-0 flex-col rounded-xl border border-border bg-bg-page-white p-4">
      <h3 className="mb-4 text-sm font-semibold text-text-primary">
        {t("dashboard.quickActions")}
      </h3>

      <div className={`grid flex-1 content-center gap-3 ${actions.length === 2 ? "grid-cols-1" : "grid-cols-1 sm:grid-cols-2"}`}>
        {actions.map((action) => {
          const Icon = action.icon;

          return (
            <Link
              key={action.id}
              href={action.href}
              className={`flex min-w-0 items-center gap-2 rounded-lg border border-border px-3 py-2.5 text-xs font-medium transition-all duration-200 hover:-translate-y-0.5 hover:border-secondary/30 hover:bg-bg-page-gray hover:shadow-sm ${action.bg} ${action.color}`}
            >
              <Icon size={16} strokeWidth={2} />
              {t(action.labelKey, action.label)}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
