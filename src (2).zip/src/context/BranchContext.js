"use client";

import {
    createContext,
    useContext,
    useEffect,
    useState
} from "react";


const BranchContext = createContext(null);


export function BranchProvider({ children }) {

    const [selectedBranch, setSelectedBranch] = useState(null);

    const [branches, setBranches] = useState([]);


    // Load saved branch when application starts
    useEffect(() => {

        try {

            const savedBranch =
                localStorage.getItem("selectedBranch");


            if (savedBranch) {

                setSelectedBranch(
                    JSON.parse(savedBranch)
                );

            }

        } catch (error) {

            console.error(
                "Load selected branch error:",
                error
            );

        }

    }, []);



    /**
     * Change current branch globally
     */
    const changeBranch = (branch) => {


        setSelectedBranch(branch);


        try {

            localStorage.setItem(
                "selectedBranch",
                JSON.stringify(branch)
            );


        } catch (error) {

            console.error(
                "Save branch error:",
                error
            );

        }



        // Notify every page/component
        window.dispatchEvent(
            new CustomEvent(
                "branchChanged",
                {
                    detail: branch
                }
            )
        );


    };



    const value = {

        selectedBranch,

        setSelectedBranch,

        changeBranch,

        branches,

        setBranches,

    };



    return (

        <BranchContext.Provider value={value}>

            {children}

        </BranchContext.Provider>

    );

}



/**
 * Main hook
 */
export function useBranch() {


    const context =
        useContext(BranchContext);



    if (!context) {

        throw new Error(
            "useBranch must be used inside BranchProvider"
        );

    }


    return context;

}



/**
 * Used by forms/pages that need to detect
 * branch changing
 */
export function useBranchChangeGuard() {


    const {
        selectedBranch
    } = useBranch();


    const [branchChanged,setBranchChanged] =
        useState(false);



    useEffect(() => {


        const handler = (event) => {


            setBranchChanged(true);


        };



        window.addEventListener(
            "branchChanged",
            handler
        );



        return () => {


            window.removeEventListener(
                "branchChanged",
                handler
            );


        };


    },[]);



    return {

        selectedBranch,

        branchChanged

    };


}