"use client";

import { Eye, FileText } from "lucide-react";

const IMAGE_TYPES = new Set([
  "JPG",
  "JPEG",
  "PNG",
  "GIF",
  "WEBP",
  "BMP",
  "SVG",
]);

function getFileType(document, fileName) {
  if (fileName.includes(".")) {
    return fileName.split(".").pop().toUpperCase();
  }

  return String(document?.file?.mimeType || "")
    .split("/")
    .pop()
    .toUpperCase();
}

function getBranchName(document) {
  return (
    document?.branch?.name_km ||
    document?.branch?.nameKm ||
    document?.branch?.name_en ||
    document?.branch?.nameEn ||
    "-"
  );
}

function getCreatedDate(document) {
  const value = document?.created_at || document?.createdAt;
  return value ? String(value).slice(0, 10) : "-";
}

function getFileSize(document) {
  const sizeKb = Number(document?.file?.sizeKb);
  return Number.isFinite(sizeKb) ? `${sizeKb.toFixed(1)} KB` : "-";
}

export function toPreviewDocument(document) {
  const fileName =
    document?.file?.originalName || document?.title || "document";
  const type = getFileType(document, fileName) || "FILE";

  return {
    ...document,
    type,
    fileName,
    fileUrl: document?.file?.id
      ? `/api/backend/files/${document.file.id}/content`
      : document?.file?.url,
    branch: getBranchName(document),
    date: getCreatedDate(document),
    size: getFileSize(document),
  };
}

export default function BackendDocumentCard({ document, onView }) {
  const previewDocument = toPreviewDocument(document);
  const isImage = IMAGE_TYPES.has(previewDocument.type);
  const isPdf = previewDocument.type === "PDF";

  const openPreview = () => onView?.(previewDocument);

  return (
    <article className="flex w-[380px] min-w-0 flex-col rounded-xl border border-gray-200 border-t-4 border-t-secondary bg-[#f8f9fc] p-3 shadow-sm">
      <h2 className="truncate text-base font-bold text-primary">
        {document?.title || "ឯកសារសមាជិក"}
      </h2>

      <button
        type="button"
        onClick={openPreview}
        aria-label={`មើលឯកសារ ${previewDocument.fileName}`}
        className="group relative mt-3 flex h-[190px] shrink-0 items-center justify-center overflow-hidden rounded-lg bg-white p-2 transition hover:ring-1 hover:ring-primary"
      >
        <span className="absolute right-3 top-3 z-10 rounded-full bg-white/95 px-3 py-1 text-xs font-semibold text-primary shadow-sm">
          {previewDocument.type}
        </span>

        {isImage ? (
          <img
            src={previewDocument.fileUrl}
            alt={document?.title || previewDocument.fileName}
            className="h-full w-full object-contain"
          />
        ) : isPdf ? (
          <iframe
            src={`${previewDocument.fileUrl}#page=1&view=FitH&toolbar=0&navpanes=0`}
            title={previewDocument.fileName}
            className="pointer-events-none h-full w-full border-0 bg-white"
          />
        ) : (
          <div className="flex flex-col items-center justify-center gap-3 text-gray-500">
            <FileText size={52} strokeWidth={1.5} />
            <span className="text-sm">ចុចដើម្បីមើលឯកសារ</span>
          </div>
        )}

        <span className="absolute inset-0 flex items-center justify-center bg-primary/0 text-white opacity-0 transition group-hover:bg-primary/20 group-hover:opacity-100">
          <span className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold shadow">
            <Eye size={17} />
            មើលឯកសារ
          </span>
        </span>
      </button>

      <div className="mt-3 space-y-2 text-xs">
        <div className="flex min-w-0 items-center justify-between gap-4">
          <span className="shrink-0 text-gray-500">ឯកសារ</span>
          <strong className="truncate text-right text-gray-900">
            {previewDocument.fileName}
          </strong>
        </div>
        <div className="flex items-center justify-between gap-4">
          <span className="text-gray-500">កាលបរិច្ឆេទ</span>
          <strong className="text-gray-900">{previewDocument.date}</strong>
        </div>
      </div>

      <button
        type="button"
        onClick={openPreview}
        className="mt-4 flex h-[34px] w-full items-center justify-center gap-2 rounded-lg bg-secondary text-xs font-semibold text-white transition hover:bg-secondary-hover active:scale-[0.99]"
      >
        <Eye size={16} />
        មើលឯកសារ
      </button>
    </article>
  );
}
