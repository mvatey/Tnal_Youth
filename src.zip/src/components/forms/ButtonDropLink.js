"use client";

import { useState } from "react";
import { ExternalLink, Link2, Trash2 } from "lucide-react";

export default function ButtonDropLink({
  value = "",
  onChange,
  placeholder = "បញ្ចូលតំណភ្ជាប់ឯកសារ",
  readOnly = false,
}) {
  const [showInput, setShowInput] = useState(Boolean(value));

  function handleCancel() {
    setShowInput(false);
    onChange?.("");
  }

  return (
    <div className="w-full">
      {value && (
        <a href={value} target="_blank" rel="noreferrer" className="mb-2 inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
          <ExternalLink size={16} />
          មើលឯកសារ
        </a>
      )}
      {readOnly ? null : (
      <>
      {!showInput ? (
        <button
          type="button"
          onClick={() => setShowInput(true)}
          className="inline-flex h-[34px]  items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-white transition hover:opacity-90"
        >
          <Link2 size={17} />
          តំណភ្ជាប់ឯកសារ
        </button>
      ) : (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Link2
              size={17}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-text-mute"
            />

            <input
              type="url"
              value={value}
              onChange={(event) => onChange?.(event.target.value)}
              placeholder={placeholder}
              className="h-10 w-full rounded-lg border border-border bg-bg-page-white pl-10 pr-3 text-sm text-text-primary outline-none focus:border-primary"
            />
          </div>

          <button
            type="button"
            onClick={handleCancel}
            className="flex size-10 items-center justify-center rounded-full border border-border bg-bg-page-white text-text-mute transition hover:bg-bg-page-gray hover:text-red-500"
          >
            <Trash2 size={18} />
          </button>
        </div>
      )}
      </>
      )}
    </div>
  );
}
