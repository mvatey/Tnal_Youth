"use client";

import { useEffect, useMemo, useState } from "react";
import DonationCard from "./DonationCard";
import DonorCard from "./DonorCard";
import useCurrentMember from "@/hooks/useCurrentMember";
import { fetchMyAccountCollection } from "@/lib/myAccountCollections";
import { useBranch } from "@/context/BranchContext";

const isCurrentMonthDonation = (row, now = new Date()) => {
  const rawPeriod = row?.donationPeriod || row?.paidAt || row?.donatedAt;
  if (!rawPeriod) return false;

  const period = new Date(`${String(rawPeriod).slice(0, 10)}T00:00:00`);
  if (Number.isNaN(period.getTime())) return false;

  return (
    period.getFullYear() === now.getFullYear() &&
    period.getMonth() === now.getMonth()
  );
};

export default function DonationCards() {
  const { member: currentMember, loading: currentMemberLoading } = useCurrentMember();
  const isBranchScoped = ["secretary", "branch_leader"].includes(currentMember?.role);
  const isMemberScoped = currentMember?.role === "member";
  const {
    branches: accessibleBranches = [],
    selectedBranch: globalSelectedBranch = "all",
  } = useBranch();

  // IMPORTANT: for SECRETARY/BRANCH_LEADER the sidebar selection is the
  // single source of truth. currentMember.branchId is only the home branch
  // and must never override a branch the secretary actively selected.
  const scopedBranchId = useMemo(() => {
    if (!isBranchScoped) return null;

    if (globalSelectedBranch && globalSelectedBranch !== "all") {
      return String(globalSelectedBranch);
    }

    if (accessibleBranches.length > 0) {
      return String(accessibleBranches[0].id);
    }

    return currentMember?.branchId ? String(currentMember.branchId) : null;
  }, [
    isBranchScoped,
    globalSelectedBranch,
    accessibleBranches,
    currentMember?.branchId,
  ]);

  const [summary, setSummary] = useState({ totalUsd: 0, donors: 0 });

  useEffect(() => {
    // Wait for the current member to resolve so a branch-scoped user
    // (secretary/branch_leader) doesn't briefly fetch org-wide totals
    // before their branch is known.
    if (currentMemberLoading) return undefined;
    if (isBranchScoped && !scopedBranchId) return undefined;

    let cancelled = false;

    if (isMemberScoped) {
      fetchMyAccountCollection("donations/monthly")
        .then((rows) => {
          if (cancelled) return;
          const currentMonthRows = rows.filter((row) =>
            isCurrentMonthDonation(row),
          );
          setSummary({
            totalUsd: currentMonthRows.reduce(
              (total, row) =>
                total + Number(row.overallTotalUsd ?? row.totalAmountUsd ?? row.amountUsd ?? 0),
              0,
            ),
            donors: currentMonthRows.length,
          });
        })
        .catch(() => { if (!cancelled) setSummary({ totalUsd: 0, donors: 0 }); });
      return () => { cancelled = true; };
    }

    const query = new URLSearchParams({ page: "0", size: "100" });
    if (isBranchScoped) query.set("branchId", String(scopedBranchId));

    fetch(`/api/backend/donations/monthly?${query}`, { cache: "no-store", credentials: "include" })
      .then(async (response) => {
        const body = await response.json().catch(() => null);
        if (!response.ok || body?.success === false) throw new Error();
        const page = body?.data ?? body;
        const rows = Array.isArray(page?.items) ? page.items : [];
        const currentMonthRows = rows.filter((row) =>
          isCurrentMonthDonation(row),
        );
        if (cancelled) return;
        setSummary(currentMonthRows.reduce((total, row) => ({
          totalUsd: total.totalUsd + Number(row.overallTotalUsd || 0),
          donors: total.donors + Number(row.donorCount || 0),
        }), { totalUsd: 0, donors: 0 }));
      })
      .catch(() => {
        if (!cancelled) setSummary({ totalUsd: 0, donors: 0 });
      });

    return () => { cancelled = true; };
  }, [currentMemberLoading, isBranchScoped, isMemberScoped, scopedBranchId]);

  return (
    <div className="flex gap-[50px] xl:grid-cols-2">
      <DonationCard label="ថវិកាប្រចាំខែ" value={`$${summary.totalUsd.toLocaleString(undefined, { maximumFractionDigits: 2 })}`} growth="0%" note="ក្នុងខែនេះ" />
      <DonorCard
        label={isMemberScoped ? "ចំនួនកំណត់ត្រា" : "អ្នកបរិច្ចាគសរុប"}
        value={`${summary.donors} ${isMemberScoped ? "លើក" : "នាក់"}`}
        growth="0%"
        note="ក្នុងខែនេះ"
      />
    </div>
  );
}
