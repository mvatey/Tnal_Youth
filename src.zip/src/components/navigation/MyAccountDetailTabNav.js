"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const MY_ACCOUNT_DETAIL_TABS = [
  { name: "ព័ត៌មានផ្ទាល់ខ្លួន", href: "personal" },
  { name: "ព័ត៌មានគ្រួសារ", href: "family" },
  { name: "ប្រវត្តិការងារ", href: "work" },
  { name: "ការអប់រំ/បណ្តុះបណ្តាល", href: "education" },
  { name: "ជំនាញបច្ចេកទេស", href: "skill" },
  { name: "កិច្ចការនយោបាយ", href: "political" },
];

export default function MyAccountDetailTabNav() {
  const pathname = usePathname();

  return (
    <div className="overflow-hidden rounded-lg bg-white shadow-sm">
      <div className="grid min-w-[900px] grid-cols-6 overflow-x-auto">
        {MY_ACCOUNT_DETAIL_TABS.map((tab) => {
          const href = `/myAcc/details/${tab.href}`;
          const active = pathname === href;

          return (
            <Link
              key={tab.href}
              href={href}
              className={`flex h-10 items-center justify-center border-t-2 px-3 text-sm font-medium transition-all ${
                active
                  ? "border-secondary bg-secondary-light text-secondary"
                  : "border-transparent text-text-secondary hover:bg-gray-50"
              }`}
            >
              <span className="truncate">{tab.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
